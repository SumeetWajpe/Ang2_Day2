export interface ICourse{
     name ?: string,
    imageUrl?:string,
    trainer?:string,
    location?:string
}