import {Component,Input} from '@angular/core';

@Component({
    selector:'product',    
    template:`
    <div productStyle class="Product" >
    <h2> {{prodDetails.name  }} </h2>
                    <b> Price :  </b> {{prodDetails.price   }} <br/>
                    <b> Quantity :  </b> {{prodDetails.quantity}} <br/>
                    <b> Rating :  </b> {{prodDetails.rating   }} <br/>
                    <b> Date : </b> {{prodDetails.launchdate  }}  <br/>
        </div>  ` ,
//         styles:[`                      
//       .Product{
//         background-color:lightblue;
//         border:2px solid black;
//         border-radius:10px;
//         padding:20px;
//         margin:20px;
//       }
//    ` ]  

styleUrls:['./app/ProductStyles.css']               
})
export class ProductComponent{
 @Input('pDetails')   prodDetails:any={};
}