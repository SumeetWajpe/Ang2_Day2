import {Component} from '@angular/core';


@Component({
    selector: 'shoppingcart',    
        // template:` `
        templateUrl:'./app/shoppingcart.html'
})
export class ShoppingCartComponent {
   heading:string = 'Shopping Cart ';

    products: any[] = [
        {
            name: 'Lappy', price: 50000, quantity: 100, rating: 4, launchdate: new Date() ,available:true,description:`Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"`   },
        { name: 'LED TV', price: 25000, quantity: 10, rating: 3.2789, launchdate: new Date(), available: true,description:`Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"`  },
        { name: 'Desktop', price: 10000, quantity: 200, rating: 3, launchdate: new Date(), available: false ,description:`Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"`  },
        { name: 'Mobile', price: 20000, quantity: 1000, rating: 5, launchdate: new Date(), available: true,description:`Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"`  },
        { name: 'Camera', price: 90000, quantity: 10, rating: 4, launchdate: new Date(), available: true,description:`Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"`   }
    ];  

}